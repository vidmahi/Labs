// name: 
// date:
// per:  

public class Lab0
{

    public Lab0()
    {
        // do not update the constructor
    }

    public  void display (int min, int max)
    {
        
    }

    public String checkValue(int value)
    {
       return null;
    }
}
